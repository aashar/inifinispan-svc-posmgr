package com.advaim.caching.infinispan.svcposmgr.datamodel;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.client.hotrod.configuration.ClientIntelligence;
import org.infinispan.client.hotrod.configuration.ConfigurationBuilder;

import java.util.Objects;

public class DataSourceConnector {
    private RemoteCacheManager remoteCacheManager;

    public DataSourceConnector() {

    }

    public DataSourceConnector(RemoteCacheManager remoteCacheManager) {
        this.remoteCacheManager = remoteCacheManager;
    }

    // Step 1 - Connect to Infinispan
    public void connect() {
        System.out.println("---- Connect to Infinispan ----");
        ConfigurationBuilder builder = new ConfigurationBuilder();

        builder.uri("hotrod://localhost:11222");

        builder.clientIntelligence(ClientIntelligence.BASIC);

        // Define the schema on the client
        builder.addContextInitializer(new PositionSchemaImpl());
        
        remoteCacheManager = new RemoteCacheManager(builder.build());
    }

    public void health() {
        checkConnection();
        System.out.println("---- Connection count: " + remoteCacheManager.getConnectionCount() + " ----");
    }

    public RemoteCache<String, Position> getPositionCache() {
        PositionMarshallingContext.initSerializationContext(remoteCacheManager); // (1)

    	return remoteCacheManager.administration().getOrCreateCache("position", "example.PROTOBUF_DIST");
    }

    public RemoteCache<String, OrderEvent> getOrderEventCache() {
        PositionMarshallingContext.initSerializationContext(remoteCacheManager); // (1)

    	return remoteCacheManager.administration().getOrCreateCache("orderEvent", "example.PROTOBUF_DIST");
    }

    private void checkConnection() {
        Objects.requireNonNull(remoteCacheManager, "Implement 'connect' in the 'DataSourceConnector' class");
    }

    public void shutdown() {
        Objects.requireNonNull(remoteCacheManager);
        System.out.println("---- Shutdown the client ----");
        remoteCacheManager.stop();
    }
}
