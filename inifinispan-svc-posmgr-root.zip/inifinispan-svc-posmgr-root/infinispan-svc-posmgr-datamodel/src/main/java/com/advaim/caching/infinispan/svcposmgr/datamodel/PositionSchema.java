package com.advaim.caching.infinispan.svcposmgr.datamodel;

import org.infinispan.protostream.SerializationContextInitializer;
import org.infinispan.protostream.annotations.AutoProtoSchemaBuilder;

@AutoProtoSchemaBuilder(
      includeClasses = {
              OrderEvent.class,
              Position.class
      },
      schemaFileName = "orderevent.proto",
      schemaFilePath = "proto/",
      schemaPackageName = "posmgmt.data")
public interface PositionSchema extends SerializationContextInitializer {
}
