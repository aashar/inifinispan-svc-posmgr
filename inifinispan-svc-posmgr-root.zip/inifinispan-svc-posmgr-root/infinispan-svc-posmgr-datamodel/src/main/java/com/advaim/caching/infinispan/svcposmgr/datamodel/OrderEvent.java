package com.advaim.caching.infinispan.svcposmgr.datamodel;

import java.util.Date;
import java.util.Objects;

import org.infinispan.protostream.annotations.ProtoField;

public class OrderEvent {

	@ProtoField(number = 1)
	public Date createDate;

	@ProtoField(number = 2) // clOrdID
	public String id;

	@ProtoField(number = 3)
	public String clientID;

	@ProtoField(number = 4)
	public String instrument;

	@ProtoField(number = 5, defaultValue = "1")
	public short side;

	@ProtoField(number = 6, defaultValue = "1000")
	public float quantity;

	@ProtoField(number = 7, defaultValue = "12.0")
	public float price;

	@ProtoField(number = 8, defaultValue = "1")
	public short targetStrategy;

//		NEW_ORDER_SINGLE ('D'), PARTIAL_FILL ('1'), FILL('2'), CANCEL('5');

	@ProtoField(number = 9, defaultValue = "D")
	public char msgType;

//		ACCEPTED (1), DONE_FOR_DAY (10), FILLED(8), CANCELED(5), PARTIALLY_FILLED(4), REPLACED(3), NEW(2);

	@ProtoField(number = 10, defaultValue = "2")
	public short ordStatus;

	@ProtoField(number = 11) // posid is ordid for a single source+dest
	public String positionID;

	@ProtoField(number = 12)
	public String source;

	@ProtoField(number = 13)
	public String destination;

	@ProtoField(number = 14, defaultValue = "0")
	public float cumQty;

	@ProtoField(number = 15, defaultValue = "1000")
	public float leavesQty;

	@ProtoField(number = 16, defaultValue = "0")
	public float avgPrice;

	@ProtoField(number = 17)
	public String origClOrdID;

	public OrderEvent() {
		// An accessible no-arg constructor is required for Protostream to be able to
		// instantiate this
	}

	public OrderEvent(final String id, final String clientID, final String instrument, final short side,
			final float quantity, final float price, final short targetStrategy, final short ordStatus,
			final char msgType, final String positionID, final String source, final String destination,
			final float cumQty, final float leavesQty, final float avgPrice, String origClOrdID) {
		this.createDate = new Date();
		this.id = id;
		this.clientID = clientID;
		this.instrument = instrument;
		this.side = side;
		this.quantity = quantity;
		this.price = price;
		this.targetStrategy = targetStrategy;
		this.msgType = msgType;
		this.ordStatus = ordStatus;
		this.positionID = positionID;
		this.source = source;
		this.destination = destination;
		this.cumQty = cumQty;
		this.leavesQty = leavesQty;
		this.avgPrice = avgPrice;
		this.origClOrdID = origClOrdID;
	}

	public OrderEvent(final String id, final String clientID, final String instrument, final short side,
			final float quantity, final float price, final short targetStrategy, final short ordStatus,
			final char msgType, final String positionID) {
		this(id, clientID, instrument, side, quantity, price, targetStrategy, ordStatus, msgType, positionID, "", "", 0,
				0, 0, "");
	}

	@Override
	public String toString() {
		return "{createDate='" + createDate.toString() + '\'' + ", id='" + id + '\'' + ", clientID='" + clientID + '\''
				+ ", instrument='" + instrument + '\'' + ", side='" + side + '\'' + ", quantity='" + quantity + '\''
				+ ", price='" + price + '\'' + ", targetStrategy='" + targetStrategy + '\'' + ", msgType='" + msgType
				+ '\'' + ", ordStatus='" + ordStatus + '\'' + ", positionID='" + positionID + '\'' + ", source='"
				+ source + '\'' + ", destination='" + destination + ", cumQty=" + cumQty + '\'' + ", leavesQty='"
				+ leavesQty + '\'' + ", avgPrice='" + avgPrice + '\'' + ", origClOrdID='" + origClOrdID + "\'}";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		OrderEvent orderEvent = (OrderEvent) o;
		return Objects.equals(createDate, orderEvent.createDate) && Objects.equals(id, orderEvent.id)
				&& Objects.equals(clientID, orderEvent.clientID) && Objects.equals(instrument, orderEvent.instrument)
				&& Objects.equals(side, orderEvent.side) && Objects.equals(quantity, orderEvent.quantity)
				&& Objects.equals(price, orderEvent.price) && Objects.equals(targetStrategy, orderEvent.targetStrategy)
				&& Objects.equals(msgType, orderEvent.msgType) && Objects.equals(ordStatus, orderEvent.ordStatus)
				&& Objects.equals(positionID, orderEvent.positionID) && Objects.equals(source, orderEvent.source)
				&& Objects.equals(destination, orderEvent.destination) && Objects.equals(cumQty, orderEvent.cumQty)
				&& Objects.equals(leavesQty, orderEvent.leavesQty) && Objects.equals(avgPrice, orderEvent.avgPrice)
				&& Objects.equals(origClOrdID, orderEvent.origClOrdID);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, clientID, instrument, side, quantity, price, targetStrategy, msgType, positionID,
				source, destination, cumQty, leavesQty, avgPrice, origClOrdID);
	}
}

/*
 * //8=FIX.4.29=16335=D34=97249=TESTBUY352=20190206-16:25:10.40356=
 * TESTSELL311=14163685067084226997921=238=10040=154=155=AAPL60=20190206-
 * 16:25:08.968207=TO6000=TEST123410=106
 */