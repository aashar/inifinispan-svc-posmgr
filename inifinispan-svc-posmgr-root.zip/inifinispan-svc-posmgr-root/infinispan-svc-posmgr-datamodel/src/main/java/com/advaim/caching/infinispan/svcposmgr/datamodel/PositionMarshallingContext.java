package com.advaim.caching.infinispan.svcposmgr.datamodel;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.RemoteCacheManager;
import org.infinispan.protostream.GeneratedSchema;
import org.infinispan.query.remote.client.ProtobufMetadataManagerConstants;

import java.util.Objects;

public class PositionMarshallingContext {
   public static void initSerializationContext(RemoteCacheManager cacheManager) {
      System.out.println("---- PositionMarshallingContext - initialize the serialization context for Position class ----");
      Objects.requireNonNull(cacheManager);

      // Retrieve metadata cache
      RemoteCache<String, String> metadataCache =
            cacheManager.getCache(ProtobufMetadataManagerConstants.PROTOBUF_METADATA_CACHE_NAME);

      GeneratedSchema schema = new PositionSchemaImpl();
      // Define the new schema on the server too
      metadataCache.put(schema.getProtoFileName(), schema.getProtoFile());
   }
}
