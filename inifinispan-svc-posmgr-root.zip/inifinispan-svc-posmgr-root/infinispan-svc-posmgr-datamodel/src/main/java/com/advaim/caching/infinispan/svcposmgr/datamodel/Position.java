package com.advaim.caching.infinispan.svcposmgr.datamodel;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import org.infinispan.protostream.annotations.ProtoField;

public class Position {

// 8=FIX.4.29=16335=D34=97249=TESTBUY352=20190206-16:25:10.40356=TESTSELL311=14163685067084226997921=238=10040=154=155=AAPL60=20190206-16:25:08.968207=TO6000=TEST123410=106

	@ProtoField(number = 1)
	public Date createDate;

	@ProtoField(number = 2)
	public String id;

	@ProtoField(number = 3)
	public String clientID;

	@ProtoField(number = 4)
	public String instrument;

	@ProtoField(number = 5, defaultValue = "1")
	public short side = 1;

	@ProtoField(number = 6, defaultValue = "1000")
	public float leavesQty = 100000;

	@ProtoField(number = 7, defaultValue = "12.0")
	public float targetPrice = 12f;

	@ProtoField(number = 8, defaultValue = "1")
	public short targetStrategy = 1;

	@ProtoField(number = 9, defaultValue = "0")
	public float cumQty = 0;

	@ProtoField(number = 10, defaultValue = "0")
	public float avgPrice;

	@ProtoField(number = 11)
	public List<OrderEvent> events = null;

//		ACCEPTED(1), DONE_FOR_DAY(10), FILLED(8), CANCELED(5), PARTIALLY_FILLED(4), REPLACED(3), NEW(2);

	@ProtoField(number = 12, defaultValue="2")
	public short ordStatus;

	public Position() {
		// An accessible no-arg constructor is required for Protostream to be able to
		// instantiate this
		this.id = UUID.randomUUID().toString();
		this.createDate = new Date();
		this.events = new ArrayList<OrderEvent>();
	}

	public Position(final String id, final String clientID, final String instrument, final short side,
			final float leavesQty, final float targetPrice, final short targetStrategy, final float cumQty,
			final float avgPrice, final short ordStatus) {
		this.createDate = new Date();
		this.id = id;
		this.clientID = clientID;
		this.instrument = instrument;
		this.side = side;
		this.leavesQty = leavesQty;
		this.targetPrice = targetPrice;
		this.targetStrategy = targetStrategy;
		this.cumQty = cumQty;
		this.avgPrice = avgPrice;
		this.ordStatus = ordStatus;
		this.events = new ArrayList<OrderEvent>();
	}

//	ACCEPTED (1), DONE_FOR_DAY (10), FILLED(8), CANCELED(5), PARTIALLY_FILLED(4), REPLACED(3), NEW(2);
//	NEW_ORDER_SINGLE ('D'), PARTIAL_FILL ('1'), FILL('2'), CANCEL('5');

	public void updatePosition(OrderEvent event) {
		this.leavesQty = event.leavesQty;
		this.cumQty = event.cumQty;
		this.avgPrice = event.avgPrice;
		if(event.msgType == 'D') {
			this.id = event.positionID;				// position id same as the first new order event id
			this.clientID = event.clientID;
			this.instrument = event.instrument;
			this.side = event.side;
			this.targetPrice = event.price;
			this.targetStrategy = event.targetStrategy;
			this.ordStatus = 2;
		} else if (event.msgType == '1' || event.msgType == '2') {
			if(this.leavesQty <= 0) {
				this.ordStatus = 8;
			} else {
				this.ordStatus = 4;
			}
		} else if (event.msgType == '5') {
			this.ordStatus = 5;
		}

		this.events.add(event);
	}

	@Override
	public String toString() {
		return "Position: {" + "createDate='" + createDate.toString() + '\'' + "id='" + id + '\'' + ", clientID='"
				+ clientID + '\'' + ", instrument='" + instrument + '\'' + ", side='" + side + '\'' + ", leavesQty='"
				+ leavesQty + '\'' + ", targetPrice='" + targetPrice + '\'' + ", targetStrategy='" + targetStrategy
				+ '\'' + ", cumQty='" + cumQty + '\'' + ", avgPrice='" + avgPrice + '\'' + ", ordStatus='"
				+ ordStatus + "\'}";
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;
		Position position = (Position) o;
		return Objects.equals(createDate, position.createDate) && Objects.equals(id, position.id)
				&& Objects.equals(clientID, position.clientID) && Objects.equals(instrument, position.instrument)
				&& Objects.equals(side, position.side) && Objects.equals(leavesQty, position.leavesQty)
				&& Objects.equals(targetPrice, position.targetPrice)
				&& Objects.equals(targetStrategy, position.targetStrategy) && Objects.equals(cumQty, position.cumQty)
				&& Objects.equals(avgPrice, position.avgPrice) && Objects.equals(ordStatus, position.ordStatus);
	}

	@Override
	public int hashCode() {
		return Objects.hash(id, clientID, instrument, side, leavesQty, targetPrice, targetStrategy, cumQty, avgPrice, ordStatus);
	}
}