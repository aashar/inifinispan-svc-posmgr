package com.advaim.caching.infinispan.svcposmgr.service;

import com.advaim.caching.infinispan.svcposmgr.datamodel.DataSourceConnector;

public abstract class IApplication {
	protected DataSourceConnector admin = null;

	public void run() {
		try {
			admin = new DataSourceConnector();
			admin.connect();
			execute();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (admin != null)
				admin.shutdown();
		}
	}

	protected abstract void execute() throws Exception;
}
