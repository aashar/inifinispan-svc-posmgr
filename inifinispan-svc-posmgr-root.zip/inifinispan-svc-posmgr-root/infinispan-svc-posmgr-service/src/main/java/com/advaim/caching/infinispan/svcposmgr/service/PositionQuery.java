package com.advaim.caching.infinispan.svcposmgr.service;

import java.util.List;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.Search;

import org.infinispan.query.dsl.Query;
import org.infinispan.query.dsl.QueryFactory;
import org.infinispan.query.dsl.QueryResult;

import com.advaim.caching.infinispan.svcposmgr.datamodel.DataSourceConnector;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class PositionQuery {
   private final RemoteCache<String, Position> cache;

   public PositionQuery(DataSourceConnector dataSourceConnector) {
      cache = dataSourceConnector.getPositionCache();
   }

   public List<Position> getPositions(String positionID) {
      QueryFactory queryFactory = Search.getQueryFactory(cache);
      Query<Position> query = queryFactory.create("FROM posmgmt.data.Position WHERE id like :positionID");
      query.setParameter("positionID", positionID);

      // Execute the query
      QueryResult<Position> queryResult = query.execute();

      return queryResult.list();
   }

   public List<Position> findPositionsByClientID(String clientID) {
      QueryFactory queryFactory = Search.getQueryFactory(cache);
      Query<Position> query = queryFactory.create("FROM posmgmt.data.Position WHERE clientID like :clientID");
      query.setParameter("clientID", clientID);

      // Execute the query
      QueryResult<Position> queryResult = query.execute();

      return queryResult.list();
   }
}
