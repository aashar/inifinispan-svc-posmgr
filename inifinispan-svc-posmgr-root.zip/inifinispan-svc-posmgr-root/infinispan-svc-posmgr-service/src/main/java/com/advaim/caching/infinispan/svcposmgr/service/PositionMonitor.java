package com.advaim.caching.infinispan.svcposmgr.service;

import java.util.ArrayList;
import java.util.List;

import org.infinispan.client.hotrod.RemoteCache;
import org.infinispan.client.hotrod.Search;
import org.infinispan.query.api.continuous.ContinuousQuery;
import org.infinispan.query.api.continuous.ContinuousQueryListener;
import org.infinispan.query.dsl.Query;
import org.infinispan.query.dsl.QueryFactory;

import com.advaim.caching.infinispan.svcposmgr.datamodel.DataSourceConnector;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class PositionMonitor {
	private final RemoteCache<String, Position> cache;
    private List<PositionUpdatesEventListener> eventListeners = new ArrayList<PositionUpdatesEventListener>();
    private List<PositionsUpdatesEventListener> listEventListeners = new ArrayList<PositionsUpdatesEventListener>();

	public PositionMonitor(DataSourceConnector dataSourceConnector) {
		cache = dataSourceConnector.getPositionCache();
	}

	public void monitorClientPositionsContinuously(String clientID) {
		// Get the query factory
		QueryFactory queryFactory = Search.getQueryFactory(cache);

		// Use Ickle to run the query
		Query<Position> query = queryFactory.create("FROM posmgmt.data.Position WHERE clientID like :clientID");

		// Set the parameter value
		query.setParameter("clientID", clientID);

		ContinuousQuery<String, Position> continuousQuery = Search.getContinuousQuery(cache);

		// Create the continuous query listener.
		ContinuousQueryListener<String, Position> listener = new ContinuousQueryListener<String, Position>() {
			@Override
			public void resultJoining(String key, Position data) {
				System.out.printf("%s%n", data.toString());
			}
			@Override
			public void resultUpdated(String key, Position data) {
				System.out.printf("%s%n", data.toString());
			}
		};

		// And the listener corresponding the query to the continuous query
		continuousQuery.addContinuousQueryListener(query, listener);
	}

	public void monitorPositionContinuously(String positionID) {
		// Get the query factory
		QueryFactory queryFactory = Search.getQueryFactory(cache);

		// Use Ickle to run the query
		Query<Position> query = queryFactory.create("FROM posmgmt.data.Position WHERE id like :positionID");

		// Set the parameter value
		query.setParameter("positionID", positionID);

		ContinuousQuery<String, Position> continuousQuery = Search.getContinuousQuery(cache);

		// Create the continuous query listener.
		ContinuousQueryListener<String, Position> listener = new ContinuousQueryListener<String, Position>() {
			@Override
			public void resultJoining(String key, Position data) {
	            eventListeners.forEach((el) -> el.onPositionUpdateEvent(data));
			}
			@Override
			public void resultUpdated(String key, Position data) {
	            eventListeners.forEach((el) -> el.onPositionUpdateEvent(data));
			}
		};

		// And the listener corresponding the query to the continuous query
		continuousQuery.addContinuousQueryListener(query, listener);
	}

	public void addPositionsUpdatesEventListener(PositionsUpdatesEventListener evtListener)
    {
        this.listEventListeners.add(evtListener);
    }
	
	public interface PositionsUpdatesEventListener {
		public void onPositionsUpdateEvent(Position position);
	}

	public void addPositionUpdatesEventListener(PositionUpdatesEventListener evtListener)
    {
        this.eventListeners.add(evtListener);
    }
	
	public interface PositionUpdatesEventListener {
		public void onPositionUpdateEvent(Position position);
	}
}
