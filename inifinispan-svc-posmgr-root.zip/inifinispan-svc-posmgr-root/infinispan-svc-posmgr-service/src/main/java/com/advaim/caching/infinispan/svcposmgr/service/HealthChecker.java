package com.advaim.caching.infinispan.svcposmgr.service;

public class HealthChecker extends IApplication {

	@Override
	protected void execute() {
		admin.health();
	}

	public static void main(String[] args) {
		new HealthChecker().run();
	}
}