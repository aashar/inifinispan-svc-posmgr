package com.advaim.caching.infinispan.svcposmgr.cli;

import com.advaim.caching.infinispan.svcposmgr.service.IApplication;
import com.advaim.caching.infinispan.svcposmgr.service.PositionMonitor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PositionMonitorApp extends IApplication {
	ObjectMapper mapper = new ObjectMapper();

    @Override
    public void execute() throws Exception {
        PositionMonitor positionMonitor = new PositionMonitor(admin);

		positionMonitor.addPositionsUpdatesEventListener((pos) -> {
			try {
				String retMsg = mapper.writeValueAsString(pos);
				System.out.println(retMsg);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

        positionMonitor.monitorClientPositionsContinuously("JPM");

        System.out.println("---- Press any key to quit ----");
        while(System.in.available() == 0) {
    		Thread.sleep(5000);
        }
    }

    public static void main(String[] args) {
        new PositionMonitorApp().run();
    }
}
