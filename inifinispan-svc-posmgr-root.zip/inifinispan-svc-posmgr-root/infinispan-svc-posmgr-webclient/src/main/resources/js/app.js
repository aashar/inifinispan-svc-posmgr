function renderView() {
	let posList = $('#positionstbl').DataTable({
		"processing": true,
		"pageLength": 15,
		ajax: {
    	    url: 'http://localhost:8080/positions?clientID=' + $("#clientIDinp").val(),
        	dataSrc: ''
	    },
		rowId: 'id',
		responsive: {
	        details: {
	            display: $.fn.dataTable.Responsive.display.modal()
	        }
	    },
        select: true,
		columns: [
			{ data: "createDate" },
			{ data: "id" },
			{ data: "clientID" },
			{ data: "instrument" },
			{ data: "side" },
			{ data: "leavesQty" },
			{ data: "targetPrice" },
			{ data: "targetStrategy" },
			{ data: "cumQty" },
			{ data: "avgPrice" },
			{ data: "events", "visible": false },
			{ data: "ordStatus" }
		]
	});

	posList.on( 'select', function ( e, dt, type, indexes ) {
        let rowData = posList.rows( indexes ).data().toArray();
        let posID = rowData[0].id;
        window.location.href = "http://localhost:8080/cqposmonitor.html?positionID=" + posID;
    } )
}

function updateData() {
	console.log("Getting data for " + $("#clientIDinp").val());
	let posList = $('#positionstbl').DataTable();
	posList.ajax.url( 'http://localhost:8080/positions?clientID=' + $("#clientIDinp").val() ).load();
}

$("#clientIDinp").change(updateData);

$(document).ready(function() {
	renderView();
});
