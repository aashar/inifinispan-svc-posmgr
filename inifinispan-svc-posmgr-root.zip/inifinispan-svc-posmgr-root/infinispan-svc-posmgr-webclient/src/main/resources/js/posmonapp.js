var tableData = [];

function refreshData() {
	const urlSearchParams = new URLSearchParams(window.location.search);
	const params = Object.fromEntries(urlSearchParams.entries());
	
	if(params.hasOwnProperty('positionID')) {
	fetch('http://localhost:8080/position?positionID=' + params.positionID,
		{method: 'GET', mode: 'no-cors', headers: { 'Accept': 'application/json'}})
		.then(response => {
			if (!response.ok) {
		      throw new Error('Network response was not ok');
    		}
			const contentType = response.headers.get('content-type');
			if (!contentType || !contentType.includes('application/json')) {
				throw new TypeError("Oops, we haven't got JSON!");
			}
			return response.json();
		})
		.then(pos => {
//			console.log('data received:' + JSON.stringify(pos));

			$('#positionIDLbl').text(pos.id);
			$('#leavesQtyLbl').text(pos.leavesQty);
			$('#cumQtyLbl').text(pos.cumQty);
			$('#avgPriceLbl').text(pos.avgPrice);
			$('#instrumentLbl').text(pos.instrument);
			$('#clientIDLbl').text(pos.clientID);
			$('#sideLbl').text(pos.side);
			$('#ordStatusLbl').text(pos.ordStatus);

			$('#eventstbl').DataTable().data = pos.events;
			$('#eventstbl').DataTable().draw();

			console.log('events received:' + JSON.stringify(pos.events));

//			$('#eventstbl').DataTable().rows.add(pos.events).draw();
//				.ajax.reload( null, false );
		})
		.catch(error => console.error("Err:" + error));
	} else {
		alert("Missing positionID Parameter");
	}
}

function renderView() {
	let posList = $('#eventstbl').DataTable({
		"processing": true,
		"pageLength": 15,
		rowId: 'id',
        select: true,
		columns: [
			{ data: "createDate" },
			{ data: "id" },
			{ data: "clientID", "visible": false },
			{ data: "instrument", "visible": false },
			{ data: "side", "visible": false },
			{ data: "quantity" },
			{ data: "price" },
			{ data: "targetStrategy" },
			{ data: "msgType" },
			{ data: "ordStatus" },
			{ data: "positionID", "visible": false },
			{ data: "source" },
			{ data: "destination" },
			{ data: "cumQty" },
			{ data: "leavesQty" },
			{ data: "avgPrice" },
			{ data: "origClOrdID" }
		]
	});
}

$(document).ready(function() {
	renderView();
	refreshData();
});