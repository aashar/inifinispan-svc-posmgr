var ws = $.gracefulWebSocket("ws://localhost:8080/websocket");
ws.onmessage = function(event) {
    let messageFromServer = event.data;
    $('#output').append('<p>Received: '+messageFromServer+'</p>');
}

function send(message) {
    ws.send(message);
}