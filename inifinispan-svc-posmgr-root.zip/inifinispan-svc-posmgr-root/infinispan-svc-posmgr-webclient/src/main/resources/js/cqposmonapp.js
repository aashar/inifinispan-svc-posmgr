var socket;
var tabData = [];

function refreshData(data) {
	let pos = JSON.parse(data.data);
	console.log('data received:' + JSON.stringify(pos));

	$('#positionIDLbl').text(pos.id);
	$('#leavesQtyLbl').text(pos.leavesQty);
	$('#cumQtyLbl').text(pos.cumQty);
	$('#avgPriceLbl').text(pos.avgPrice);
	$('#instrumentLbl').text(pos.instrument);
	$('#clientIDLbl').text(pos.clientID);
	$('#sideLbl').text(pos.side);
	$('#ordStatusLbl').text(pos.ordStatus);

	$('#eventstbl').DataTable().clear().draw();
	$('#eventstbl').DataTable().rows.add(pos.events).draw();

/*	let foo = $('#eventstbl').DataTable().row('#7d1c285d-3866-490d-ba84-4e7d8d0d1269');
	foo.data();

	console.log(
		JSON.stringify(bar)
	);	*/
}

function renderView() {
	$('#eventstbl').DataTable({
		"pageLength": 15,
		rowId: 'id',
        select: true,
        data: tabData,
		columns: [
			{ data: "createDate" },
			{ data: "id" },
			{ data: "clientID", "visible": false },
			{ data: "instrument", "visible": false },
			{ data: "side", "visible": false },
			{ data: "quantity" },
			{ data: "price" },
			{ data: "targetStrategy" },
			{ data: "msgType" },
			{ data: "ordStatus" },
			{ data: "positionID", "visible": false },
			{ data: "source" },
			{ data: "destination" },
			{ data: "cumQty" },
			{ data: "leavesQty" },
			{ data: "avgPrice" },
			{ data: "origClOrdID" }
		]
	});
}

function send(message) {
    if (!window.WebSocket) {
        return false;
    }
    if (socket.readyState == WebSocket.OPEN) {
        socket.send(message);
    } else {
        alert("The socket is not open.");
    }
    return false;
}

$(document).ready(function() {
	renderView();

    if (window.WebSocket) {
        socket = new WebSocket("ws://localhost:8080/cqposmonws");
        socket.onmessage = function (event) {
			refreshData(event);
        };
        socket.onopen = function(event) {
    		const urlSearchParams = new URLSearchParams(window.location.search);
			const params = Object.fromEntries(urlSearchParams.entries());

			if(params.hasOwnProperty('positionID'))
	        	socket.send("positionID:" + params.positionID);
        	else
        		console.log("PositionID not available");
		};
    } else {
        alert("Your browser does not support Websockets");
    }
});
