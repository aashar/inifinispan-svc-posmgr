package com.advaim.caching.infinispan.svcposmgr.webclient;

import com.advaim.caching.infinispan.svcposmgr.service.IApplication;
import com.advaim.caching.infinispan.svcposmgr.service.PositionMonitor;
import com.advaim.caching.infinispan.svcposmgr.service.PositionQuery;

import io.undertow.Undertow;
import io.undertow.server.handlers.resource.ClassPathResourceManager;

import static io.undertow.Handlers.path;
import static io.undertow.Handlers.resource;

public class WebInterface extends IApplication {
	PositionMonitor positionMonitor = null;
	PositionQuery positionQuery = null;

    @Override
    public void execute() throws Exception {
    	positionMonitor = new PositionMonitor(admin);
    	positionQuery = new PositionQuery(admin);

        Undertow server = Undertow.builder()
                .addHttpListener(8080, "localhost")
                .setHandler(path()
                        .addPrefixPath("/positions", new PositionListHttpHandler(positionQuery))
                        .addPrefixPath("/position", new PositionHttpHandler(positionQuery))
                        .addPrefixPath("/websocket", new TestSocketHandler())
                        .addPrefixPath("/cqposmonws", new PositionQueryWebCQHandler(positionMonitor))
                        .addPrefixPath("/", resource(new ClassPathResourceManager(WebInterface.class.getClassLoader())).addWelcomeFiles("index.html")))
                .build();
        server.start();

        System.out.println("---- Press any key to quit ----");
        while(System.in.available() == 0) {
    		Thread.sleep(5000);
        }

        server.stop();
    }

    public static void main(String[] args) {
        new WebInterface().run();
    }
}
