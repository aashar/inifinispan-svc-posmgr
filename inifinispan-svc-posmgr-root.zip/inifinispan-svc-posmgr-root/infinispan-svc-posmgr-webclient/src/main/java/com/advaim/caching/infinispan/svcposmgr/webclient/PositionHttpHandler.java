package com.advaim.caching.infinispan.svcposmgr.webclient;

import java.util.Deque;

import com.advaim.caching.infinispan.svcposmgr.service.PositionQuery;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;

public class PositionHttpHandler implements HttpHandler {
	PositionQuery positionQuery = null;
	ObjectMapper mapper = new ObjectMapper();

	public PositionHttpHandler(PositionQuery positionQuery) {
		this.positionQuery = positionQuery;
	}

	@Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "application/json");

        Deque<String> value = exchange.getQueryParameters().get("positionID");

        if (value == null) {
            exchange.getResponseSender().send(
        		"{'Error': 'Missing positionID Parameter'}"
    		);
        } else {
        	String retMsg = mapper.writeValueAsString(positionQuery.getPositions(value.getFirst()).get(0));
        	System.out.println("Event:" + retMsg);

        	exchange.getResponseSender().send(
    			retMsg
			);
        }
    }
}