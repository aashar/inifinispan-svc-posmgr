package com.advaim.caching.infinispan.svcposmgr.webclient;

import com.advaim.caching.infinispan.svcposmgr.service.PositionMonitor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.undertow.websockets.WebSocketConnectionCallback;
import io.undertow.websockets.WebSocketProtocolHandshakeHandler;
import io.undertow.websockets.core.AbstractReceiveListener;
import io.undertow.websockets.core.BufferedTextMessage;
import io.undertow.websockets.core.WebSocketChannel;
import io.undertow.websockets.core.WebSockets;
import io.undertow.websockets.spi.WebSocketHttpExchange;

public class PositionQueryWebCQHandler extends WebSocketProtocolHandshakeHandler {
	PositionMonitor positionMonitor = null;
	static ObjectMapper mapper = new ObjectMapper();
	static WebSocketChannel webChannel = null;

	public PositionQueryWebCQHandler(PositionMonitor positionMonitor) {
		super(new WebSocketConnectionCallback() {
            @Override
            public void onConnect(WebSocketHttpExchange exchange, WebSocketChannel channel) {
            	webChannel = channel;
                channel.getReceiveSetter().set(new AbstractReceiveListener() {
                    @Override
                    protected void onFullTextMessage(WebSocketChannel channel, BufferedTextMessage message) {
                        final String messageData = message.getData();
                        if(messageData.startsWith("positionID:")) {
                        	String[] splits = messageData.split(":");
							positionMonitor.monitorPositionContinuously(splits[1]);
                        } else {
                        	System.err.println("Received unexpected:" + messageData);
                        }
                    }
                });

                channel.resumeReceives();
            }
        });

		this.positionMonitor = positionMonitor;

		positionMonitor.addPositionUpdatesEventListener((pos) -> {
			try {
				String retMsg = mapper.writeValueAsString(pos);
	            WebSockets.sendText(retMsg, webChannel, null);
			} catch (JsonProcessingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}
}
