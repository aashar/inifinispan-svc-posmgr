package com.advaim.caching.infinispan.svcposmgr.webclient;

import io.undertow.websockets.WebSocketConnectionCallback;
import io.undertow.websockets.WebSocketProtocolHandshakeHandler;
import io.undertow.websockets.core.AbstractReceiveListener;
import io.undertow.websockets.core.BufferedTextMessage;
import io.undertow.websockets.core.WebSocketChannel;
import io.undertow.websockets.core.WebSockets;
import io.undertow.websockets.spi.WebSocketHttpExchange;

public class TestSocketHandler extends WebSocketProtocolHandshakeHandler {
	public TestSocketHandler() {
		super(new WebSocketConnectionCallback() {
	        @Override
	        public void onConnect(WebSocketHttpExchange exchange, WebSocketChannel channel) {
	            channel.getReceiveSetter().set(new AbstractReceiveListener() {
	
	                @Override
	                protected void onFullTextMessage(WebSocketChannel channel, BufferedTextMessage message) {
	                    final String messageData = message.getData();
	                    for (WebSocketChannel session : channel.getPeerConnections()) {
	                        WebSockets.sendText(messageData, session, null);
	                    }
	                }
	            });
	            channel.resumeReceives();
	        }
		});
	}
}
