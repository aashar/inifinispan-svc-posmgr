package com.advaim.caching.infinispan.svcposmgr.webclient;

import java.util.Deque;

import com.advaim.caching.infinispan.svcposmgr.service.PositionQuery;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;

public class PositionListHttpHandler implements HttpHandler {
	PositionQuery positionQuery = null;
	ObjectMapper mapper = new ObjectMapper();

	public PositionListHttpHandler(PositionQuery positionQuery) {
		this.positionQuery = positionQuery;
	}

	@Override
	public void handleRequest(HttpServerExchange exchange) throws Exception {
        Deque<String> value = exchange.getQueryParameters().get("clientID");

        StringBuilder msg = new StringBuilder();
        
        msg.append("[");

        if (value == null) {
            msg.append("Missing clientID Parameter");
        } else {
            positionQuery.findPositionsByClientID(value.getFirst()).forEach(position -> {
            	if(position != null) {
					try {
						msg.append(mapper.writeValueAsString(position) + ",");
					} catch (JsonProcessingException e) {
						e.printStackTrace();
					}
            	}
				else
            		msg.append("Position not found: " + value.getFirst());
            });
        }
        if(msg.length() > 1)
        	msg.replace(msg.length()-1, msg.length(), "]");
        else
        	msg.append("]");

        exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "application/json");
        exchange.getResponseSender().send(msg.toString());
    };
}
