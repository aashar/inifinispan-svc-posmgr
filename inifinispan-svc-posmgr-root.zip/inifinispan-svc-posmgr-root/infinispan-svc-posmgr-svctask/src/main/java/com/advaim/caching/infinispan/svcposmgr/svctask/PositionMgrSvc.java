package com.advaim.caching.infinispan.svcposmgr.svctask;

import org.infinispan.Cache;
import org.infinispan.tasks.ServerTask;
import org.infinispan.tasks.TaskContext;

import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class PositionMgrSvc implements ServerTask<Position> {
	private TaskContext ctx;
	public void setTaskContext(TaskContext taskContext) {
		this.ctx = taskContext;
	}

	public Position call() throws Exception {
		final OrderEvent event = (OrderEvent) ctx.getParameters().get().get("orderEvent");
		Cache<String, Position> cache = ctx.getCacheManager().getCache("position");

		Position position = cache.get(event.positionID);
		if(position == null) {
			position = new Position();
		}
		position.updatePosition(event);
		cache.put(event.positionID, position);

		return position;
	}

	public String getName() {
		return "position-manager";
	}
}