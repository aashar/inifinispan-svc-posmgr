package com.advaim.caching.infinispan.svcposmgr.testdata.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class MultiPosEventsFactory extends IEventsFactory {
	public MultiPosEventsFactory(String source, String destination) {
		super(source, destination);
	}

	Map<String, Position> positionCache = new HashMap<String, Position>();

//	ACCEPTED (1), DONE_FOR_DAY (10), FILLED(8), CANCELED(5), PARTIALLY_FILLED(4), REPLACED(3), NEW(2);
//	NEW_ORDER_SINGLE ('D'), PARTIAL_FILL ('1'), FILL('2'), CANCEL('5');

	public OrderEvent getNextEvent() {
		OrderEvent ordEvent = null;
		Position position = null;

		Random random = new Random();
		int rand = random.nextInt(100);
		if (positionCache.size() < 100 || rand > 90) { // initial 100 or 10% new positions
			ordEvent = newRandomEvent();
			position = new Position();
			position.updatePosition(ordEvent);
			positionCache.put(position.id, position);
		} else if (rand < 10) { // 20% deletes
			String key = positionCache.keySet().toArray()[random.nextInt(positionCache.size())].toString();
			position = positionCache.get(key);

			ordEvent = delEvent(position);
			positionCache.remove(key);
		} else { // 80% updates
			String key = positionCache.keySet().toArray()[random.nextInt(positionCache.size())].toString();
			position = positionCache.get(key);

			ordEvent = fillRandomEvent(position);

			position.updatePosition(ordEvent);
			if (position.ordStatus == 8) {
				positionCache.remove(key);
			} else {
				positionCache.put(position.id, position);
			}
		}
		return ordEvent;
	}
}
