package com.advaim.caching.infinispan.svcposmgr.testdata.service;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public abstract class IEventsFactory {
	private static final String clientsListString = "BRK.B,JPM,V,BAC,MA,WFC,C,MS,GS,BLK,AMT,SCHW,AXP,SPGI,PLD";
	private static final String	securitiesListString = "AAPL,GOOGL,GOOG,MSFT,AMZN,FB,JPM,JNJ,XOM,BAC,WMT,WFC,V,BRK.B,T,HD,CVX,UNH,INTC,PFE,VZ,PG,BA,ORCL,CSCO,C,KO,MA,CMCSA,ABBV,DWDP,PEP,DIS,PM,MRK,IBM,MMM,NVDA,GE,MCD,AMGN,MO,NFLX,HON,MDT,GILD,NKE,UTX,BMY,ABT,UNP,TXN,ACN,LMT,MS,GS,SLB,UPS,QCOM,ADBE,AVGO,CAT,PCLN,USB,PYPL,KHC,CHTR,BLK,LLY,TMO,LOW,COST,AXP,CRM,SBUX,CVS,CELG,TWX,PNC,WBA,SCHW,NEE,BIIB,CB,FDX,DHR,FOX,MDLZ,COP,GD,CL,GM,ANTM,EOG,AMT,AET,RTN,NOC,SYK,AGN,BK,ITW,CME,AIG,OXY,MON,ATVI,DE,DUK,AMAT,BDX,MAR,ADP,EL,CCL,MET,MU,TJX,SPG,PSX,CI,COF,D,CSX,PRU,SPGI,CTSH,ISRG,EBAY,CCI,EMR,FOXA,LYB,SO,HAL,PX,ESRX,F,BBT,MMC,STZ,ICE,INTU,NSC,TGT,KMB,VRTX,VLO,TRV,KMI,ECL,DAL,STT,EA,SHW,HUM,MNST,BSX,ZTS,ETN,REGN,BAX,WM,AON,TEL,HPQ,JCI,ALL,EXC,APD,HCA,LUV,AFL,EQIX,BHGE,STI,FIS,ILMN,PSA,APC,PLD,ADI,VFC,AEP,MPC,MCK,GIS,PGR,SYY,MCO,PXD,ROST,PPG,SYF,CMI,LRCX,MTB,EW,DFS,RCL,DXC,ROP,YUM,TSN,APH,FISV,DG,HLT,ALXN,SRE,WY,FCX,TROW,GLW,KR,DLTR,FTV,APTV,WMB,HPE,WDC,AAL,SWK,IP,ZBH,PH,ADSK,PCAR,PEG,ROK,ADM,AMP,ED,PAYX,NTRS,RHT,IR,KEY,FITB,COL,K,CXO,CFG,OKE,A,AVB,BEN,MYL,RSG,XEL,RF,ORLY,DLR,DPS,CERN,DISH,GGP,HCN,EQR,HSY,PPL,BBY,WLTW,ABC,CAH,CBS,IQV,PCG,NUE,HIG,AZO,MHK,NEM,EXPE,MGM,SBAC,EIX,MCHP,UAL,DVN,WEC,VTR,ALGN,SWKS,PFG,CTL,WYNN,INCY,HRS,ES,CNC,INFO,DTE,BXP,DHI,OMC,HRL,LH,AME,LNC,XLNX,VMC,GPN,HBAN,CTAS,MSI,CLX,SYMC,WRK,MTD,CMA,LLL,L,KLAC,WAT,ANDV,TSS,VRSK,DOV,IDXX,NTAP,FAST,TXT,TDG,APA,URI,GWW,LEN,GPC,CBG,NWL,HST,ESS,CAG,TPR,EMN,CA,FTI,EFX,STX,HES,AWK,MRO,LB,O,BLL,MLM,ETFC,FE,DVA,ADS,IVZ,SJM,DGX,CPB,MKC,MAS,XRAY,NLSN,ULTA,RMD,RJF,CTXS,NCLH,NBL,ANSS,ETR,COTY,CBOE,JBHT,NOV,CHRW,XYL,AEE,NDAQ,TIF,VNO,SNPS,HAS,GPS,EQT,LKQ,PNR,TAP,PRGO,WHR,ARNC,ARE,WYN,AJG,CINF,CMS,GRMN,CHD,KMX,ALB,DRI,BWA,PVH,HSIC,CNP,SNI,COO,FMC,IFF,UNM,AMD,HOLX,UHS,PKG,EXPD,KSU,HCP,AKAM,CDNS,IT,COG,AOS,VRSN,XL,VAR,ZION,HII,VIAB,KSS,AMG,EXR,RE,AVY,XEC,KORS,MAA,QRVO,REG,MOS,FBHS,TMK,SNA,NWS,IRM,NWSA,JEC,JNPR,CF,UDR,DRE,WU,LUK,PHM,DISCA,RL,FFIV,LNT,SLG,MAC,TSCO,PNW,PKI,DISCK,IPG,GT,JWN,HOG,AAP,FRT,NRG,HBI,SEE,FLR,XRX,ALK,NI,CMG,ALLE,M,HP,BHF,RHI,AES,FLIR,PBCT,AYI,SRCL,KIM,AIV,LEG,UAA,MAT,FL,TRIP,NFX,BF.B,FLS,HRB,UA,PWR,SCG,CSRA,AIZ,EVHC,NAVI,RRC,PDCO,SIG,CHK";
	private static final float initQty = 1000;
	private static final float defFillQty = 100;

	// USERS will be used to create random positions
	private static final List<String> CLIENTS = Arrays.asList(
		   clientsListString.split(","));

	// HASHTAGS will be used to create random positions
	private static final List<String> SECURITIES = Arrays.asList(
		   securitiesListString.split(","));

	String source, destination, clientID, instrument = null;

//	ACCEPTED (1), DONE_FOR_DAY (10), FILLED(8), CANCELED(5), PARTIALLY_FILLED(4), REPLACED(3), NEW(2);
//	NEW_ORDER_SINGLE ('D'), PARTIAL_FILL ('1'), FILL('2'), CANCEL('5');

	public IEventsFactory(String source, String destination, String clientID, String instrument) {
		this.source = source;
		this.destination = destination;
		this.clientID = clientID;
		this.instrument = instrument;
	}

	public IEventsFactory(String source, String destination, String clientID) {
		this(source, destination, clientID, "");
	}

	public IEventsFactory(String source, String destination) {
		this(source, destination, "", "");
	}

	abstract public OrderEvent getNextEvent();

	public OrderEvent newRandomEvent() {
		return new OrderEvent(
				UUID.randomUUID().toString(),
				clientID.isEmpty() ? CLIENTS.get(new Random().nextInt(CLIENTS.size())) : clientID,
				instrument.isEmpty() ? SECURITIES.get(new Random().nextInt(SECURITIES.size())) : instrument,
				(short)(new Random().nextInt(2)+1),
				initQty,
				(float)Math.floor(100 * 12 * (1 + new Random().nextFloat() * 5 / 100))/100, // 12 + upto 5%
				(short)new Random().nextInt(5),
				(short)2,
				'D',
				UUID.randomUUID().toString(),
				source,
				destination,
				0,
				initQty,
				0,
				"");
	}

	public OrderEvent fillRandomEvent(Position position) {
		OrderEvent firstEvent = position.events.get(0);
		String posSource = firstEvent.source, posDestination = firstEvent.destination;

		OrderEvent lastEvent = position.events.get(position.events.size()-1);

		float price = (float)Math.floor(100 * position.targetPrice * (1 + new Random().nextFloat() * 5 / 100))/100; // 5% of targetPrice

		long numOfPricedEvents = position.events.stream().filter(evt ->  evt.msgType == '1' || evt.msgType == '2' ).count();
		float avgPrice = (position.avgPrice * numOfPricedEvents + price) / (numOfPricedEvents + 1);

		return new OrderEvent(
				UUID.randomUUID().toString(),
				position.clientID,
				position.instrument,
				position.side,
				defFillQty,
				price,
				position.targetStrategy,
				position.leavesQty <= defFillQty ? (short)8 : (short)4,
				position.leavesQty <= defFillQty ? '2' : '1',
				position.id,
				posDestination,
				posSource,
				position.cumQty + defFillQty,
				position.leavesQty - defFillQty,
				avgPrice,
				lastEvent.id);
	}

	public OrderEvent delEvent(Position position) {
		OrderEvent firstEvent = position.events.get(0);
		String posSource = firstEvent.source, posDestination = firstEvent.destination;
		OrderEvent lastEvent = position.events.get(position.events.size()-1);

		return new OrderEvent(
				UUID.randomUUID().toString(),
				position.clientID,
				position.instrument,
				position.side,
				position.leavesQty,
				0,
				position.targetStrategy,
				(short)5,
				'5',
				position.id,
				posSource,
				posDestination,
				position.cumQty,
				0,
				position.avgPrice,
				lastEvent.id);
	}

	public enum FactoryType {
		SinglePosition, MultiPositions;
	}
}
