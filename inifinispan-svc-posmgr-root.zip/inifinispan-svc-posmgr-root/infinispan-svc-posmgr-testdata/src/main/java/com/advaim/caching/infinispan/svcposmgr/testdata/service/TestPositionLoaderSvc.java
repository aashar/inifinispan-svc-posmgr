package com.advaim.caching.infinispan.svcposmgr.testdata.service;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.infinispan.client.hotrod.RemoteCache;

import com.advaim.caching.infinispan.svcposmgr.datamodel.DataSourceConnector;
import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class TestPositionLoaderSvc {
	private final RemoteCache<String, Position> cache;

	public TestPositionLoaderSvc(DataSourceConnector dataSourceConnector) {
		cache = dataSourceConnector.getPositionCache();
	}

	public void loadPositions(long numOfPositions, IEventsFactory.FactoryType type) throws Exception {
		cache.clear();
		IEventsFactory factory = null;

		if(type.equals(IEventsFactory.FactoryType.MultiPositions))
			factory = new MultiPosEventsFactory("src1", "dest1");
		else if(type.equals(IEventsFactory.FactoryType.SinglePosition))
			factory = new OnePosEventsFactory("src1", "dest1", "JPM", "ZVV");
		else
			throw new Exception("Unknown Factory Type");

		for (int i = 0; i < numOfPositions; i++) {
			OrderEvent event = factory.getNextEvent(); // get next event
			Map<String, OrderEvent> params = new HashMap<String, OrderEvent>();
			params.put("orderEvent", event);
			cache.execute("position-manager", params, event.positionID);
		}

		// Get total number of events
		int result = cache.keySet()
				.parallelStream().map(e -> Integer.valueOf(cache.get(e).events.size()))
				.collect(Collectors.summingInt(i -> i.intValue()));

		System.out.printf("Events = %d, in %d positions loaded\n", result, cache.size());
	}
}
