package com.advaim.caching.infinispan.svcposmgr.testdata;

import com.advaim.caching.infinispan.svcposmgr.service.IApplication;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.IEventsFactory;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.TestPositionLoaderSvc;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.IEventsFactory.FactoryType;


public class ServerSidePositionMgmtApp extends IApplication {
	FactoryType factoryType = null;

	public ServerSidePositionMgmtApp() {
		factoryType = IEventsFactory.FactoryType.MultiPositions;
	}

	@Override
    protected void execute() {
		TestPositionLoaderSvc positionLoader = new TestPositionLoaderSvc(admin);

		long start = System.nanoTime();
		try {
			positionLoader.loadPositions(50000, factoryType);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Duration: " + (System.nanoTime() - start)/1000000 + "ms");
    }

	public static void main(String[] args) {
		ServerSidePositionMgmtApp app = new ServerSidePositionMgmtApp();
		app.run();
    }
}
