package com.advaim.caching.infinispan.svcposmgr.testdata;

import com.advaim.caching.infinispan.svcposmgr.service.IApplication;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.IEventsFactory;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.IEventsFactory.FactoryType;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.TestPositionLoader;

public class PositionLoaderApp extends IApplication {

	FactoryType factoryType = null;

	public PositionLoaderApp() {
		factoryType = IEventsFactory.FactoryType.MultiPositions;
	}

	@Override
    protected void execute() {
        TestPositionLoader positionLoader = new TestPositionLoader(admin);

		long start = System.nanoTime();
		try {
			positionLoader.loadPositions(50000, factoryType);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Updated 50,000 positions in " + (System.nanoTime() - start)/1000000 + "ms time");
    }

	public static void main(String[] args) {
		PositionLoaderApp app = new PositionLoaderApp();
		app.run();
    }
}
