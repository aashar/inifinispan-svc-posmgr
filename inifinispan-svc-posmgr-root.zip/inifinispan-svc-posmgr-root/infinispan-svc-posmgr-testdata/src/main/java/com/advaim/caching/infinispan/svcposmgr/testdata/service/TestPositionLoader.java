package com.advaim.caching.infinispan.svcposmgr.testdata.service;

import org.infinispan.client.hotrod.RemoteCache;

import com.advaim.caching.infinispan.svcposmgr.datamodel.DataSourceConnector;
import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class TestPositionLoader {
	private final RemoteCache<String, Position> cache;

	public TestPositionLoader(DataSourceConnector dataSourceConnector) {
		cache = dataSourceConnector.getPositionCache();
	}

	public void loadPositions(long numOfPositions, IEventsFactory.FactoryType type) throws Exception {
		IEventsFactory factory = null;

		if(type.equals(IEventsFactory.FactoryType.MultiPositions))
			factory = new MultiPosEventsFactory("src1", "dest1");
		else if(type.equals(IEventsFactory.FactoryType.SinglePosition))
			factory = new OnePosEventsFactory("src1", "dest1", "JPM", "ZVV");
		else
			throw new Exception("Unknown Factory Type");

		for (int i = 0; i < numOfPositions; i++) {
			OrderEvent event = factory.getNextEvent(); // get next event
			Position position = cache.get(event.positionID); // get position from cache if exists
			if (position == null) {
				position = new Position();
			}
			position.updatePosition(event); // update position as per the event
			cache.put(position.id, position); // update position in cache
		}
	}
}
