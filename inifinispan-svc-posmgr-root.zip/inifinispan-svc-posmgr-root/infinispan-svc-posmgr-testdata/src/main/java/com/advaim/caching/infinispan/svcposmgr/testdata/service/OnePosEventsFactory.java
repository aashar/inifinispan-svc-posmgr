package com.advaim.caching.infinispan.svcposmgr.testdata.service;

import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;

public class OnePosEventsFactory extends IEventsFactory {
	public OnePosEventsFactory(String source, String destination, String clientID, String instrument) {
		super(source, destination, clientID, instrument);
	}

	Position position = null;

	public OrderEvent getNextEvent() {
		OrderEvent ordEvent = null;

		if (position == null) { // New Position
			ordEvent = newRandomEvent();
			position = new Position();
			position.updatePosition(ordEvent);
		} else if (position.leavesQty <= 200) {
			ordEvent = delEvent(position);
			position.updatePosition(ordEvent);
		} else {
			ordEvent = fillRandomEvent(position);
			position.updatePosition(ordEvent);
		}
		return ordEvent;
	}
}
