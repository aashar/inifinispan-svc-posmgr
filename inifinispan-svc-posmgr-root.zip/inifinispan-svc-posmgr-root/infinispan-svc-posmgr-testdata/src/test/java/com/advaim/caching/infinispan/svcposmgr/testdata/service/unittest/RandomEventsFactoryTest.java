package com.advaim.caching.infinispan.svcposmgr.testdata.service.unittest;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.advaim.caching.infinispan.svcposmgr.datamodel.OrderEvent;
import com.advaim.caching.infinispan.svcposmgr.datamodel.Position;
import com.advaim.caching.infinispan.svcposmgr.testdata.service.MultiPosEventsFactory;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RandomEventsFactoryTest {
	static MultiPosEventsFactory factory = null;
	static Position position = null;
	static String prevClOrdID = "";

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		position = new Position();
		factory = new MultiPosEventsFactory("src1", "dest1");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		factory = null;
		position = null;
		prevClOrdID = "";
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
    @Order(1)
	void testNewRandomEvent() {  // New Order Test
		OrderEvent event = factory.newRandomEvent();
		
		position.updatePosition(event);
		prevClOrdID = event.id;

		Assertions.assertEquals(event.positionID, position.id);
		Assertions.assertNotNull(position.clientID);
		Assertions.assertEquals(event.clientID, position.clientID);
		Assertions.assertNotNull(position.instrument);
		Assertions.assertEquals(event.instrument, position.instrument);
		Assertions.assertEquals(event.side, position.side);
		Assertions.assertEquals(event.quantity, position.leavesQty);
		Assertions.assertEquals(event.targetStrategy, position.targetStrategy);
		Assertions.assertEquals(0, position.cumQty, 0);
		Assertions.assertEquals(0, position.avgPrice, 0);
		Assertions.assertEquals(2, position.ordStatus, 2);
		Assertions.assertEquals(1, position.events.size(), 1);
		Assertions.assertEquals(event, position.events.get(0));
	}

	@Test
    @Order(2)
	void testFillRandomEvent() {  // Part Fills Test
		for(short i=0; i<9; i++) {
			OrderEvent event = factory.fillRandomEvent(position);
			position.updatePosition(event);
	
			Assertions.assertEquals(event.positionID, position.id);
			Assertions.assertNotNull("For attempt #" + Integer.toString(i), position.clientID);
			Assertions.assertEquals(event.clientID, position.clientID);
			Assertions.assertNotNull(position.instrument);
			Assertions.assertEquals(event.instrument, position.instrument);
			Assertions.assertEquals(event.side, position.side);
			Assertions.assertEquals(event.targetStrategy, position.targetStrategy);
			Assertions.assertEquals(100f, event.quantity);
			Assertions.assertEquals(1000f - (i+1) * 100f, position.leavesQty);
			Assertions.assertEquals((i+1)*100f, position.cumQty);
			Assertions.assertNotEquals(0, position.avgPrice);
			Assertions.assertEquals((short)4, position.ordStatus);
			Assertions.assertEquals((i+2), position.events.size());
			Assertions.assertEquals(event, position.events.get(i+1));
			Assertions.assertEquals(event.origClOrdID, prevClOrdID);

			prevClOrdID = event.id;
		}
	}

	@Test
    @Order(3)
	void testGetNextEvent() { // Complete Fill Test
		OrderEvent event = factory.fillRandomEvent(position);
		position.updatePosition(event);

		Assertions.assertEquals(event.positionID, position.id);
		Assertions.assertNotNull(position.clientID);
		Assertions.assertEquals(event.clientID, position.clientID);
		Assertions.assertNotNull(position.instrument);
		Assertions.assertEquals(event.instrument, position.instrument);
		Assertions.assertEquals(event.side, position.side);
		Assertions.assertEquals(event.targetStrategy, position.targetStrategy);
		Assertions.assertEquals(100, event.quantity);
		Assertions.assertEquals(0, position.leavesQty);
		Assertions.assertEquals(1000, position.cumQty);
		Assertions.assertNotEquals(0, position.avgPrice);
		Assertions.assertEquals(8, position.ordStatus);
		Assertions.assertEquals(11, position.events.size());
		Assertions.assertEquals(event, position.events.get(10));
		Assertions.assertEquals(event.origClOrdID, prevClOrdID);
	}

	@Test
    @Order(4)
	void testDelEvent() {  // Cancel Order Test
		position = new Position();
		OrderEvent event0 = factory.newRandomEvent();
		position.updatePosition(event0);

		OrderEvent event1 = factory.fillRandomEvent(position);
		position.updatePosition(event1);
		prevClOrdID = event1.id;

		OrderEvent event2 = factory.delEvent(position);
		position.updatePosition(event2);

		Assertions.assertEquals(event2.positionID, position.id);
		Assertions.assertNotNull(position.clientID);
		Assertions.assertEquals(event2.clientID, position.clientID);
		Assertions.assertNotNull(position.instrument);
		Assertions.assertEquals(event2.instrument, position.instrument);
		Assertions.assertEquals(event2.side, position.side);
		Assertions.assertEquals(event2.targetStrategy, position.targetStrategy);
		Assertions.assertEquals(900, event2.quantity);
		Assertions.assertEquals(0, position.leavesQty);
		Assertions.assertEquals(100, position.cumQty);
		Assertions.assertEquals(5, position.ordStatus);
		Assertions.assertEquals(3, position.events.size());
		Assertions.assertEquals(event2.origClOrdID, prevClOrdID);
		Assertions.assertEquals(event2, position.events.get(2));
	}
}
